package com.example.version11;

public class Rword {
    private String renglish;
    private String rchinese;

    public Rword(String renglish, String rchinese) {
        this.renglish = renglish;
        this.rchinese = rchinese;
    }

    public String getRenglish() {
        return renglish;
    }

    public String getRchinese() {
        return rchinese;
    }


}
